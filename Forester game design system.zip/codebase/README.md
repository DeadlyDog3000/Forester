# Forester — design system

Two files. Copy both into the repo root beside `index.html`.

    forester-ui.css       the system as code
    design-system.html    the browsable spec, self-contained and offline

## Wiring it up

In `index.html`, replace the whole inline `<style>` block with:

```html
<link rel="stylesheet" href="forester-ui.css">
```

Nothing should look different. Every value in the stylesheet was lifted out of
the block it replaces — the only change is that each one now has a name, and
there is one place to change it.

`game.js` needs no changes. Class names and IDs are unchanged.

## What's in it

Ten layers, in cascade order: tokens, base, surfaces, controls, measures,
records, panels, overlays, touch, small screens. The one breakpoint
(`820px` / coarse-pointer `1100px`) is written once, at the bottom, and holds
every small-screen rule.

Tokens are prefixed `--fx-`. The groups:

| group | what it holds |
|---|---|
| `--fx-floor`, `--fx-glass`, `--fx-menu`, `--fx-control`, `--fx-well`… | surfaces |
| `--fx-line*` | every border colour, plus `--fx-hair: 1px` |
| `--fx-ink` … `--fx-ink-6` | the six-step ramp down from white |
| `--fx-gold*`, `--fx-spruce`, `--fx-good` | the two accents |
| `--fx-health`, `--fx-blood`, `--fx-fever`, `--fx-law`, `--fx-tag` | one hue per state |
| `--fx-territory`, `--fx-border`, `--fx-coat` | the player's three; the game overwrites these at runtime |
| `--fx-t-*`, `--fx-track-*`, `--fx-lh-*` | type |
| `--fx-pad-*`, `--fx-gap-*`, `--fx-stack` | space |
| `--fx-w-*`, `--fx-hud-h`, `--fx-inset` | where panels sit |
| `--fx-tap-*`, `--fx-sheet-h`, `--fx-pad-lane` | finger sizes |
| `--fx-z-*` | the ledger of layers, `5` through `141` |

### Two things worth knowing

**Player colour is set from JS, not CSS.** The three colour inputs in the
government panel should write to the custom properties rather than to inline
styles, so anything themed by them follows automatically:

```js
document.documentElement.style.setProperty('--fx-territory', terrColor.value);
document.documentElement.style.setProperty('--fx-border',     bordColor.value);
document.documentElement.style.setProperty('--fx-coat',       uniColor.value);
```

The canvas can read them back with
`getComputedStyle(document.documentElement).getPropertyValue('--fx-territory')`.

**New helper classes.** A handful of patterns that were repeated as inline
styles now have names, so new panels don't have to re-derive them:

- `.fx-sec` — a spruce section head inside a panel
- `.fx-note` — a footnote, the quietest line in a group
- `.fx-field` — a field sunk into the glass
- `.fx-close` — the `[close]` affordance
- `.fx-screen` / `.fx-screen-scrim` / `.fx-screen-stack` / `.fx-screen-title` /
  `.fx-screen-sub` — a full-screen card (menu, game over)
- `.btn.fx-block` — a full-width stacked action
- `.fx-row` — a label-left, value-right row (same as the existing `.row`)

They're additive. Existing markup keeps working untouched; use them when you
add something new.

## Open questions I did not decide

Two inconsistencies are documented as-is in the spec rather than settled,
because settling them changes how the game looks:

1. **Panel widths** run 240 / 280 / 318 / 470 / 520 / 560 / 720 / 760. They're
   all tokens now (`--fx-w-*`), so a tightened scale is a one-file change.
2. **Half-pixel type sizes** — 9.5, 10.5, 11.5, 12.5 — exist because 11 was
   thin and 12 was loud. Real, but a five-step scale would be easier to hold
   in your head.

Say the word and I'll propose a scale for either.
